    <div class="footer">

    	<p><a class="rol_top " href="#top"><span class="glyphicon glyphicon-arrow-up"></span>Top</a></p>
    	<p class="container" style="color: #fff; padding-top: 10px">
    	<?php
    	include_once('./../include/config.php');
    	echo $copyright;
    	?>
    	</p>
    </div>    
</body>
</html>
