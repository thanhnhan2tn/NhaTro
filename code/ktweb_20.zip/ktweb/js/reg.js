$(document).ready(function() {
    $("#btn_submit").click(function() {
        var temp = 0;
        var username = document.forms["form"]["us_name"].value;
        if ((username.length) == 0) {
            $("#check_id").html("Tên đăng nhập không được để trống");
            $("input[name=us_name]").focus();
            temp = 1;
        } else if (username.length < 3) {
            $("#check_id").html("Tên đăng nhập ít nhất 3 ký tự");
            $("input[name=us_name]").focus();
            temp = 1;
        } else $("#check_id").html(" ");

        var password = document.forms["form"]["us_pass"].value;
        if ((password.length) == 0) {
            $("#check_pass").html("Mật khẩu không được để trống");
            $("input[name=us_pass]").focus();
            temp = 1;
        } else if ((password.length) < 8) {
            $("#check_pass").html("Mật khẩu ít nhất 8 ký tự");
            $("us_pass").focus();
            temp = 1;
        } else $("#check_pass").html(" ");

        var re_password = document.forms["form"]["us_repass"].value;
        if ((re_password.match(password)) == null) {
            $("#check_repass").html("Mật khẩu chưa khớp");
            $("us_repass").focus();
            temp = 1;
        } else $("#check_repass").html(" ");


        if (temp == 1) return false;
        else if (temp == 0) return true;
    })
});