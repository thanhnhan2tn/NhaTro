<?php  
/*
// File Footer
Coder: Thai Thanh Nhan
Info
    - Email: thanhnhan2tn@mail.com
    - SĐT: 0939 87 00 77
*/
?>
<!-- Footer  -->
<div id="footer" class="container">
		<a class="rol_top" href="#top"><span class="glyphicon glyphicon-arrow-up"></span>Top</a>
		
		<div class="footer">
		
			<div class="pageContent">
			<ul class="foot_menu">
				<li><span class="glyphicon glyphicon-home"></span><a href="./">Trang chủ</a></li>
				<!-- li class="glyphicon glyphicon-envelope"><a href="./?gopy">Liên hệ, góp ý</a></li -->
				<li><span class="glyphicon glyphicon-envelope"></span><a href="./gopy.html">Liên hệ, góp ý</a></li> 
				<li><span class="glyphicon glyphicon-envelope"></span><a href="./huongdan.html">Hướng dẫn</a></li> 
						 
			</ul>
			</div>
		
		</div>
		<div class="info">© Nhóm lập trình Web
		</div>
	
</div>