<style type="text/css">
	.address-maps, .bodytext, .nhatro-cont{
		-webkit-border-radius: 4px;
		-moz-border-radius: 4px;
		border-radius: 4px;
		-ms-box-shadow: 0 1px 1px rgba(0,0,0,0.1);
		-moz-box-shadow: 0 1px 1px rgba(0,0,0,0.1);
		-o-box-shadow: 0 1px 1px rgba(0,0,0,0.1);
		-webkit-box-shadow: 0 1px 1px rgba(0,0,0,0.1);
		box-shadow: 0 1px 1px rgba(0,0,0,0.1);
		background: #fff;
		margin: 15px 0;
		display: block;
		overflow: hidden;
		border: 1px solid #DBDBDB;
		border-radius: 5px;
		position: relative;
		}
	.nhatro-count,.nhatro-point{
		display: block;
	}
	.nhatro-count{
		box-shadow: 0 1px 1px rgba(0,0,0,0.1);
		background: #fff;
		margin: 0 0 15px;
		height: 520px;
		border: 1px solid #E0E0E0;
		border-radius: 5px;

	}
	.nhatro-img{
		float: left;
		position: relative;
		padding: 3px;
		border-right: 1px dashed #ccc;
		display: block;
		height: 475px;
	}
	.nhatro-img .img {
		display: inline-block;
		overflow: hidden;
		width: 475px;
		height: auto;
		text-align: center;
	}
	.img-info{
		overflow: hidden;
		border-bottom: 1px solid #969696;
	}
	.img-info .nhatro-info {
		float: right;
		width: 430px;
		position: relative;
	}
	.title >h2{
		font-size: 28px;
		height: 44px;
		color: #682992;
		overflow: hidden;
		text-align: center;
	}
	.nhatro-info .price {
		width: 99%; 
	   height: 50px; 
	   background: rgb(0,71,255);
	   background-image: linear-gradient(#1788BE ,#4FA6FD);
	   -moz-border-radius: 25px / 25px; 
	   -webkit-border-radius: 25px / 25px; 
	   border-radius: 25px / 25px;
		right: 0;
		top: 80px;
		position: absolute;
		text-align: center;
		padding: 8px 10px;
		vertical-align: middle;
		}
	.price .prices{
		color: #FFF;
		font: bold 34px/35px arial;
		text-shadow: 0 1px 1px #000;
		}
	.prices .parameters {
		float: left;
		padding-left: 15px;
		}
	.parameters div {
		float: left;
		line-height: 36px;
		padding-left: 20px;
		}
	.parameters div>span {
		font-weight: 700;
		color: #0071B2;
		}
	
</style>

<div id="detail">
	<div class="nha-intro">
		<div class="nhatro-cont">
			<div class="img-info">
				<div class="nhatro-img">
					<div class="address-like">
					</div>
					<div class="img"><img src="http://localhost/LapTrinhWeb/code/ktweb/template/img/default.png"></div>
					<div class="new">
					</div> <!-- // New -->

				</div> <!-- //nhatro-img -->
				<div class="nhatro-info">
					<div class="title">
                    	<h2>Nhà trọ số 1</h2> <!-- //title -->
                    </div> <!-- // title -->
					<div class="price">
						 
							<span class="prices">Giá: 135.000 đ</span><span>/Người/Tháng</span>
						 
					</div>  <!-- // Price -->
					  

				</div> <!-- // Nha tro info -->

			</div>

			<div class="nhatro-point">
				<div class="parameters">
					<div>
						<i class="glyphicon glyphicon-eye-open padding-5"></i>Lượt xem: <span>340</span>
					</div>
					<div class="like">
						<i class="glyphicon glyphicon-thumbs-up padding-5"></i>Yêu thích: <span id="hdvn_1129_likes">0</span>
					</div>
				</div>
				<div class="share">
					<div id="fb-root" class=" fb_reset">
					</div>

				</div> <!-- // share -->
			</div>
		</div> <!-- nha intro -->

<div class="address-maps">
		<div class="maps">
		<!-- google maps -->
		</div>
</div>
<div class="bodytext">
  	<div class="details">
		<h1>Thông tin chi tiết</h1>
    </div>
</div>		
</div> <!-- details -->

<div class="order-bottom">
	<div class="Page">
		<div class="prd_rate">
		<p><a title="Đăng nhập" href="/index.php?language=vi&amp;com=users&amp;fun=login&amp;nv_redirect=aHR0cDovL2RlYWx0aWNodGFjLmNvbS9ob3RkZWFsL0FvLXZlc3QvQW8ta2hvYWMtU0dTLVRoYXQtTHVuZy0xMTI5Lmh0bWwjZm9ybWNvbW1lbnQ,">Bạn phải đăng nhập thành viên mới được gửi bình luận tại đây</a></p>
			<div id="showcomment"></div>
		</div>
	</div>
</div>
	<div id="key" class="order-bottom">
   		<div class="keywords">
       	<strong>Từ khóa: </strong>
        	
    	</div>

    </div>

    



</div>