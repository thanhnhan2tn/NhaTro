jQuery(document).ready(function() {
	
	$("#btnReset").click(function() 
	{
			location.reload();
	});
	
	
	$("#Submit").click(function() 
	{
		var check = 1;
		//console.log(check); //Nam o duoi    //alert(check); hien o tren
		//Kiem tra dien tich su dung
		var dtsd = $("#DTSD").val();
		if(dtsd < 1) 
		{	
			$("#DTSD").val("0");
			$("#DTSD").focus();
			$("#jsdtsd").removeClass();
			$("#jsdtsd").addClass("show");
			check = 0;
		} 
		else 
		{
			$("#jsdtsd").removeClass();
			$("#jsdtsd").addClass("hide");
		}
		
		/*
		//Kiem tra noi dung mo ta
		if ($("#Detail").val().length==0)
		{
			$("#Detail").val("");
			$("#Detail").focus();
			$("#jsDetail").removeClass();
			$("#jsDetail").addClass("show");
			check = 0;
		}
		else
		{
			$("#jsDetail").removeClass();
			$("#jsDetail").addClass("hide");
		}
		*/
		
		//Kiem tra gia cho thue
		var cost = $("#cost").val();
		if(cost < 1 || cost>1000000000) 
		{	
			$("#cost").val("0");
			$("#cost").focus();
			$("#jscost").removeClass();
			$("#jscost").addClass("show");
			check = 0;
		} 
		else 
		{
			$("#jscost").removeClass();
			$("#jscost").addClass("hide");
		}
		
		//Kiemm tra hoten
		if ($("#name").val().length==0 || $("#name").val().length>30) 
		{
			//alert("Nhập lại họ tên");
			$("#name").val("");
			$("#name").focus();
			$("#jsname").removeClass();
			$("#jsname").addClass("show");
			check = 0;
		} 
		else 
		{
			$("#jsname").removeClass();
			$("#jsname").addClass("hide");
		}		
		
		
		//Kiem tra dien thoai di dong
		if ($("#Mobile").val().length<10 || $("#Mobile").val().length>11)
		{
			$("#Mobile").val("");
			$("#jsMobile").removeClass();
			$("#jsMobile").addClass("show");
			$("#Mobile").focus();
			check = 0;
		} 
		else
		{
			$("#jsMobile").removeClass();
			$("#jsMobile").addClass("hide");	
		}
		
		
		//alert(check);
		
		
		/*
		
		
		//Kiem tra email
		var regEmail = /^([\w\._])+\@([\w\-])+\.([a-zA-Z]{2,4})(\.[a-zA-Z]{2,4})?(\.[a-zA-Z]{2,4})?$/;
		if (!regEmail.test($("#email").val())) 
		{
			//alert("Vui lòng nhập email đúng định dạng!");
			$("#ddemail").removeClass();
			$("#ddemail").addClass("show");
			$("#email").focus();
			check = 0;
		} 
		else
		{
			$("#ddemail").removeClass();
			$("#ddemail").addClass("hide");			
		}
		
		//Kiem tra nhap bao mat
		if ($("#baomat").val()!=$("#xnbaomat").val())
		{
			//alert("Nhập bảo mật sai, vui lòng nhập lại!");
			$("#ddbaomat").removeClass();
			$("#ddbaomat").addClass("show");
			$("#baomat").focus();
			check = 0;
		}
		else
		{
			$("#ddbaomat").removeClass();
			$("#ddbaomat").addClass("hide");
			
		}
		*/
		
		if (check==1) 
		{
			alert("Thông tin đã được đăng tải thành công! :) ");
		} 
	}
)
    
});