<?php  
/*
// File list nhà trọ ra ngoài trang chủ
Coder: Thai Thanh Nhan
Info
    - Email: thanhnhan2tn@mail.com
    - SĐT: 0939 87 00 77
*/
?>
<ul class="item">

      <?php for ($i=0; $i < 100; $i++) { 
        
      ?>
          <li>
            <a href="#" title="Điện thoại di động Samsung Galaxy S5">
            <div class = "span_gia">
            <span style="text-align:center; display:block;height: 120px;">
              <img src="./template/img/default.png" width="auto" height="100px" alt="Nhà trọ ví dụ">
            </span>
              <span class="special">
                <h4><span class="glyphicon glyphicon-home"></span>  Nhà trọ <?php echo $i; ?></h4>
                <h4><span class="glyphicon glyphicon-usd"></span>  Giá: 15.990.000₫</h4>
                <h5><span class="glyphicon glyphicon-hand-right"></span> Đặt biệt: Có camera an ninh</h5>
                <span class="clear-fix">
              </span>
            </div>
            <div class="bginfo clear-fix">
                <ul class="list-group">
                  <li class="list-group-item ">Cras justo odio</li>
                  <li class="list-group-item">Dapibus ac facilisis in</li>
                  <li class="list-group-item">Morbi leo risus</li>
                  <li class="list-group-item">Porta ac consectetur ac</li>
                  <li class="list-group-item">Vestibulum at eros</li>
                </ul>
            </div></a>
          </li>
      <?php
      }    
      ?>
</ul>