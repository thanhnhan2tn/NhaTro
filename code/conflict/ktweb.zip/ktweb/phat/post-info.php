 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 <link rel="stylesheet" type="test/css" href="post_info_sefl.css" />

 <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
 <script type="text/javascript" src="../plugin/ckeditor/ckeditor.js"></script>
 <script type="text/javascript" src="../plugin/ckeditor/sample.js"></script>
  <script src="post-info.js"></script>
  <div class="wrap">
  	 
	<div id="post_info_1" class="rounded_style_1 rounded_box col_900 margin_bottom">
        <div class="headline_16">
			<h2>THÔNG TIN CƠ BẢN</h2>
		</div>
        <div class="body">
			<fieldset>
            
					<li class="post_type">
						<label>
							Loại tin đăng <span class="hightlight">*</span>
						</label>
						<div class="option">
                        	<select id="TitleRight" name="TitleRight">
								<option value="Phòng trọ cho thuê">Phòng trọ cho thuê</option>
								<option value="Cho thuê nhà giá rẻ">Cho thuê nhà giá rẻ</option>
								<option value="Tìm người ở ghép">Tìm người ở ghép</option>
							</select>
							
						</div>
					</li>
                    
                    
					<li class="location">
						<label>
							Vị trí <span class="hightlight">*</span>
						</label>
						<div class="select" style="width:650px;">	
                            <span id="districtMember">
								<select class="last" id="DistrictListMember" name="DistrictListMember">
                                    <option value="">Ninh Kiều</option>
                                    <!--
                                    <option value="">Cái Răng</option>
                                    <option value="">Bình Thủy</option>
                                    <option value="">Ô Môn</option>
                                    <option value="">Thốt Nốt</option>
                                    <option value="">Phong Điền</option>
                                    <option value="">Cờ Đỏ</option>
                                    <option value="">Thới Lai</option>
                                    <option value="">Vĩnh Thạnh</option>
                                    -->
								</select>
							</span>
                            
                            
							<?php 
								require ('../include/mysqlConnect.php');
								$sql = sprintf('SELECT phuong_name FROM phuong;');
								$rs=$mysqli->query($sql);
								$op_phuong="";
								while($row=$rs->fetch_array()){
								  $op_phuong.="<option>{$row[0]}</option>";
								}
								$sql2 = sprintf('SELECT duong_name FROM duong;');
								$rs2=$mysqli->query($sql2);
								$op_duong="";
								while($row=$rs2->fetch_array()){
								  $op_duong.="<option>{$row[0]}</option>";
								}
								$mysqli->close();
                            ?>
                            
                            
							<span id="wardMember" style="margin-left:10px;">
								<select id="WardListMember" name="WardListMember">
									<!--<option value="">Phường/Xã;</option>-->
                                    
                                    <select id="option-phuong" name="option-phuong">
                                    <option selected disabled>Chọn Phường</option>
                                    <?php echo $op_phuong; ?>
                                    </select> <!-- / -->
                                    
                                    <select id="option-duong" name="option-duong">
                                    <option selected disabled>Chọn Đường</option>
                                    <?php echo $op_duong; ?>
                                    </select> <!-- / -->
                                    
								</select>
							</span>
							<!--
							<span id="streetMember">
								<select class="last" id="StreetListMember" name="StreetListMember">
									<option value="">Đường</option>
								</select>
							</span>
							-->
							<input id="HouseNumber" maxlength="150" name="HouseNumber" placeholder="Số nhà" type="text" value="" />
                        </div>   
                    </li>
                    
                    
					<li class="living_area"><label>Diện tích sử dụng <span class="hightlight">*</span></label>
						<div class="number">
							<input id="DTSD" maxlength="9" name="DTSD" type="text" value="0" />m<sup>2</sup>
                            <p id="jsdtsd" class="hide" >Nhập diện tích sử dụng</p> 
							
						</div>
					</li>
                    
                    
					<li class="living_area"><label>Tiêu đề đăng tin <span class="hightlight">*</span></label>
						<div class="number">
							<input id="Title" maxlength="50" name="Title" style="width:360px;float:none" type="text" value="" />
							<p class="hide" id="jsTitle">Chọn tiêu đề đăng tin</p>
						</div>
					</li>
                    
                    
					<li class="living_area"><label>Nội dung mô tả</label><br/>
						<div class="number">
							<textarea class="ckeditor" cols="20"  rows="100" id="Detail" name="Detail" style="height:80px;width:517px;float:none"></textarea>
						</div>
					</li>
                    
                    
					<li class="living_area"><label>Giá cho thuê <span class="hightlight">*</span></label>
						<div class="number">
							<input id="cost" maxlength="9" name="cost" type="text" value="0" /> vnđ / tháng 
						</div>
                        <p class="hide" id="jscost">Nhập giá cho thuê</p>
					</li>
                    
				</ul>
                
			</fieldset>
		</div>
    </div>
	
	
    
    <div id="post_info_1" class="rounded_style_1 rounded_box col_900 margin_bottom">
        <div class="headline_16"><h2>THÔNG TIN LIÊN HỆ</h2></div>
		<div class="body">
			<fieldset>
				<ul>
					<li class="phone"><label>Họ tên <span class="hightlight">*</span></label>
						<div class="option">
							<input id="name" maxlength="50" name="name" style="width:510px;float:none" type="text" value="" />
						</div>
                        <p class="hide" id="jsname">Nhập họ tên</p>
					</li>
					<li class="phone"><label>Điện thoại bàn</label>
						<div class="option">
						<input id="ContactPhone" maxlength="40" name="ContactPhone" type="text" value="" /> 
						</div>
					</li>
					<li class="phone"><label>Di động <span class="hightlight">*</span></label>
						<div class="option">
						<input id="Mobile" maxlength="40" name="Mobile" type="text" value="" />
						</div>
                        <p class="hide" id="jsMobile">Nhập điện thoại di động</p>
					</li>
				
				</ul>
			</fieldset>
		</div>
    </div>
	
	

	<div id="post_info_6" class="rounded_style_1 rounded_box col_900">
		<div class="headline_16"><h2>HOÀN TẤT</h2></div>
		<div class="body">   
			<div class="content">   	
				<h5>Lưu ý:</h5>
				<p>Những mục có dấu * là thông tin phải điền đầy đủ. Chỉ khi bạn hoàn tất những thông tin được yêu cầu điền đầy đủ thì các chức năng <strong>Đăng thông tin</strong> mới được kích hoạt</p>
				<fieldset>
					<ul>
						<li class="agree">
							<div class="info">
								<p>Khi nhấn nút <strong>ĐĂNG THÔNG TIN</strong>, bạn đã xác nhận hoàn toàn đồng ý với những <a href="#" target="_blank"><strong>điều khoản thỏa thuận</strong></a></p>
							</div>
						</li>
						<li>
							<button type="submit" name="Submit" id="Submit" class="btn_2"><span>ĐĂNG THÔNG TIN</span></button>
                            <button type="reset" value="Hủy bỏ" id="btnReset">Hủy bỏ</button></td>
						</li>
					</ul>
				</fieldset>
			</div>
		</div>
	</div>
</div>
           
		   
		   
		   
		   
		   