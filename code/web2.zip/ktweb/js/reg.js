$(document).ready(function() {
	$("#btn_submit").click(function(){
	var temp=0;
	var username=document.forms["form"]["us_name"].value;
	if((username.length)==0){	
		$("#check_id").text("Tên đăng nhập không được để trống");
		$("us_name").focus();
		temp=1;
	}
	else if (username.length<8){
		$("#check_id").text("Tên đăng nhập ít nhất 8 ký tự");
		$("us_name").focus();
		temp=1;
	}
	else $("#check_id").text(" ");
	
	var password=document.forms["form"]["us_pass"].value;
	if((password.length)==0){	
		$("#check_pass").text("Mật khẩu không được để trống");
		$("us_pass").focus();
		temp=1;
	}
	else if((password.length)<8){
		$("#check_pass").text("Mật khẩu ít nhất 8 ký tự");
		$("us_pass").focus();
		temp=1;
	}
	else $("#check_pass").text(" ");
	
	var re_password=document.forms["form"]["us_repass"].value;
	if((re_password.match(password))==null){
		$("#check_repass").text("Mật khẩu chưa khớp");
		$("us_repass").focus();
		temp=1;
	}
	else $("#check_repass").text(" ");
	
	
			if (temp==1) return false;
			else if (temp==0 )return true;
	})
});
