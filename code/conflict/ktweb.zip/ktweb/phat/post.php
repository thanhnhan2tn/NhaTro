<html>
<body>
<?php
	
	//Ket noi csdl
	$mysqli=new mysqli('localhost', 'root', '', 'csdl_n8');
	if ($mysqli->connect_error)
	{
		die('Connect Error ('.$mysqli->connect_errno . ') '
			. $mysqli->connect_error);
	}
	
	//Luu thong tin ve tua sach va phan gioi thieu vao bang books
	if(isset($_POST["title"]) && isset ($_POST["introduction"]))
	{
		$sql="insert into bookstore.books(title, introduction)".
			"value(' ".$_POST["title"] . " ',' ".
			$mysqli->escape_string($_POST["introduction"])."');";
		$mysqli->query($sql) or die ($mysqli->error);
	}
	else
	{
		echo "book's information is required";
		exit;
	}
	
	
	//Luu anh vao bang images
	$book_id=$mysqli->insert_id;
	$image=$_FILES[$image_fieldname];
	$image_filename=$image['name'];
	$image_mime_type=$image['type'];
	$image_size=$image['size'];
	$image_data = file_get_contents($image['tmp_name']);
	$insert_image_sql = "insert into images ".
		"(book_id, filename, mime_type, file_size, image_data)".
		"values ({$book_id}, '{$image_filename}', '{$image_mime_type}',".
		"'{$image_size}', '{$mysqli->escape_string($image_data)}');";
	$mysqli->query($insert_image_sql) or die ($mysqli->error);

?>



</body>
</html>