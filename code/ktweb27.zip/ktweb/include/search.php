<form class="navbar-form" role="search">
    <div class="form-group"><span class="">Tìm kiếm:</span>  
              <input type="text" class="form-control" placeholder="Từ khóa tìm kiếm">
    </div>
        <button type="submit" class="btn btn-default">
              <i class="glyphicon glyphicon-search" style="padding: 3px;"></i>
        </button>
 </form>
<!-- // div navi -->
