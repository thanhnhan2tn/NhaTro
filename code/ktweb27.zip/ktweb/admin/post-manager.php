<?php
// post-manager.php
// Quản trị bài viết đã đăng
// Thêm, sửa, xóa bài viết
?>