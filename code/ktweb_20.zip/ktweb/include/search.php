<form class="navbar-form" role="search">
    <div class="form-group"><span class="">Tìm kiếm:</span>
    <select id="option-type" name="option-type">
        <option selected disabled>Chọn loại phòng</option>
        <option value="1">Cho Thuê</option>
        <option value="2">Share Phòng</option>
        <option value="3">Cần Bán</option>
    </select> <!-- / -->
            
            <select id="option-phuong" name="option-phuong">
              <option selected disabled>Chọn Phường</option>
              <?php echo $op_phuong; ?>
            </select> <!-- / -->
            
            <select id="option-duong" name="option-duong">
              <option selected disabled>Chọn Đường</option>
              <?php echo $op_duong; ?>
            </select> <!-- / -->

              <input type="text" class="form-control" placeholder="Từ khóa tìm kiếm">
    </div>
              <button type="submit" class="btn btn-default"><i class="glyphicon glyphicon-search" style="padding: 3px;"></i></button>
            </form>
<!-- // div navi -->
