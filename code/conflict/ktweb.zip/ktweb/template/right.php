<script type="text/javascript">
  // Sidebar
$(document).ready(function() {
    $(".callToAction").click(function() {
        $(".sidebar").toggle("slow");
    });
});
  
</script>
<style type="text/css" >
.content h4{
 	margin: 0;
	padding: 0;
	}
.content ul{
	list-style:none;
	padding:5px 0 0 0;
	}
.margin_bottom{
	margin-bottom:10px;
}
.sidebarToggle span{
    font-size: 15pt;
    clear: both;
    display: block;
    padding: 10px;
    border: 1px solid;
    margin: 10px;
    border-radius: 9px;
    color: #fff;
    text-align: center;
    background: rgb(51, 114, 170);
    background-image: linear-gradient(rgb(37, 85, 128),rgb(23, 99, 167),rgb(81, 144, 201));
}
</style>
<div class="sidebarToggle" style="clear: both; cursor: pointer;">
<a class="callToAction" data-target=".sidebar">
    <span>Thanh bên <strong>↓</strong></span></a>
</div>
<div class="sidebar">
<form action="" name="Fillter" id="Fillter" method="post" class="Fillter" enctype="multipart/form-data">
  <div id="filter_normal" class="margin_bottom" style="display:block">
    <div class="content">
      <div id="sorttype" class="panel panel-default">
        <div class="panel-heading">
          <h4>Loại tin đăng</h4>
       	</div>
           <div class="panel-body">
              <fieldset>
                <ul>
                  <li>
                    <input type="radio" name="TinDang" id="at_1" value="1">
                    <label for="at_1">Cần bán</label>
                  </li>
                  <li>
                    <input type="radio" name="TinDang" id="at_2" value="2">
                    <label for="at_2">Cho thuê</label>
                  </li>
                  <li>
                    <input type="radio" name="TinDang" id="at_3" value="3">
                    <label for="at_3">Share phòng</label>
                  </li>
                   
                </ul>
              </fieldset>
              <input type="hidden" id="HDTinDang" name="HDTinDang" value="1">
            </div>
         
        </div>
      
      <div id="location" class="panel panel-default">
          <div class="panel-heading">
            <h4>Khu vực</h4>
          </div>
          <div class="panel-body">
              <fieldset>
                
                  <div id="" class="district margin_bottom">
                      <div class="wid-left"></div>
                        <div class="wid">
                          <div class="selector" id="uniform-DistrictList" style="width: 190px;">
                            <select name="DistrictList" id="DistrictList" style="opacity: 1; left: 2px;height:30px; width: 99%; min-width: 150px;">
                            <?php 
                            
                            ?>
                            </select>
                          </div>
                      </div>
                  </div>
                  <div class="bussiness_type margin_bottom">
            	            <div id="ward">
                                <div class="divUni-2">
                                    <div class="wid-left"></div>
								    <div class="wid">
                                <div class="selector" id="uniform-WardList" style="width: 190px;">
                                <select name="DistrictList" id="DistrictList" style="opacity: 1; left: 2px;height:30px; width: 99%; min-width: 150px;">
                                    <option value="">Phường/Xã</option>
                                    <option value="2289">An Bình</option>
                                    <option value="1310">An Cư</option>
                                    <option value="1307">An Hòa</option>
                                    <option value="1311">An Hội</option>
                                    <option value="1316">An Khánh</option>
                                    <option value="1313">An Lạc</option>
                                    <option value="1308">An Nghiệp</option>
                                    <option value="10219">An Phú</option>
                                    <option value="1306">Cái Khế</option>
                                    <option value="1315">Hưng Lợi</option>
                                    <option value="1312">Tân An</option>
                                    <option value="1309">Thới Bình</option>
                                    <option value="1314">Xuân Khánh</option>
                                </select></div>
                                    </div>
                                </div>
                            </div>
          	            </div>
                  <div class="bussiness_type margin_bottom">
                    <div id="street">
                      <div class="divUni-2">
                        <div class="wid-left"></div>
                        <div class="wid">
                          <div class="selector" id="uniform-DistrictList" style="width: 190px;">
                            <select name="DistrictList" id="DistrictList" style="opacity: 1; left: 2px;height:30px; width: 99%; min-width: 150px;">
                              		<option value="">Đường</option>
                                    <option value="2926">3 Tháng 2</option>
                                    <option value="2908">Hùng Vương</option>
                                    <option value="2904">Ngô Quyền</option>
                                    <option value="2928">Ngô Văn Sở</option>
                                    <option value="2901">Nguyễn Trãi</option>
                                    <option value="2911">Nguyễn Tri Phương</option>
                                    <option value="2857">Trần Hưng Đạo</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
               
              </fieldset>
              <input type="hidden" id="HDKhuVuc" name="HDKhuVuc" value="1">
          </div>
        </div>
        
        
     <div id="price" class="panel panel-default">
          <div class="panel-heading">
            <h4>Khoảng giá</h4>
          </div>
          <div class="panel-body">
                <input type="radio" value="0#0" /><label>Giá thương lượng </label><br />
                <input type="radio" value="0#500000"><label>Dưới 500.000</label><br />
                <input type="radio" value="500000#1000000"><label>500000 - 1.000.000</label><br />
                <input type="radio" value="100001#1500000"><label>Trên 1.000.000 - 1.500.000</label><br />
                <input type="radio" value="1500001#2000000"><label>Trên 1.500.000- 2.000.000</label><br />
                <input type="radio" value="2000000#0"><label>Trên 2.000.000</label><br />
              <input type="hidden" id="HDKhoangGiaPost" name="HDKhoangGiaPost" value="-1#-1"><br />
              <input type="hidden" id="HDKhoangGia" name="HDKhoangGia" value="1"><br />
            </div>
          </div>
	
        
        <div id="body_number" class="panel panel-default">
          <div class="panel-heading">
            <h4>Số người ở</h4>
          </div>
          <div class="panel-body">
              <fieldset>
                <div class="divUni-2">
                  <div class="wid-left"></div>
                  <div class="wid">
                    <div class="selector" id="uniform-NumberOfBedRoomList" style="width: 190px;">
                      <select name="NumberOfBedRoomList" id="NumberOfBedRoomList" style="opacity: 1; left: 2px; height:30px;width: 99%; min-width: 150px;">
                        <option value="" selected="selected">Chọn số người ở</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6+">nhiều hơn 6</option>
                      </select>
                    </div>
                  </div>
                </div>
              </fieldset>
              <input type="hidden" id="HDPhongNgu" name="HDPhongNgu" value="1">
            </div>
          </div>
          </div> <!-- end content -->
		</div>
    </div>
  </div>
</form>
</div>