<?php
// update-post.php
// Thưc thi các lệnh thêm, sửa, xóa bài viết


?>