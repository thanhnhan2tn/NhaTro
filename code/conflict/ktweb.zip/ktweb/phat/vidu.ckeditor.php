<head>
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
  <script type="text/javascript" src="../plugin/ckeditor/ckeditor.js"></script>
 <link rel="stylesheet" type="text/css" href="../plugin/ckeditor/sample.css" />
</head>
<body>
<?php
echo $_POST["Detail"];
?>
</body>