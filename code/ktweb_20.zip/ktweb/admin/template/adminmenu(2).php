<div class="menu dropdown"  style="color: #fff; padding: 0; margin: 0;">
      	<div class="navbar navbar-static-top navbar-inverse" style="position: initial;color: #fff; padding: 0; margin: 0;">
      		<h3 style="margin:10px 0;"><span class="glyphicon glyphicon-cog" style="padding-right:10px;"></span>Tùy chọn </h3>
      	</div>
	  	  <ul>
	  	   <li><a href="./admin.php"><span class="glyphicon glyphicon-dashboard"></span><span class="menuitem">Bảng điều khiển</span></a> </li>
		   <li><a href="./danhmuc.php"><span class="glyphicon glyphicon-list-alt"></span><span class="menuitem">Quản lý danh mục</span></a></li>
		  <li><a href="./kenh.php"><span class="glyphicon glyphicon-play-circle"></span><span class="menuitem">Quản lý kênh</span></a></li>
		  <li><a href="./admin.php?tab=gopy"><span class="glyphicon glyphicon-envelope"></span><span class="menuitem">Quản lý góp ý</span></a></li>
		  </ul>
      </div>