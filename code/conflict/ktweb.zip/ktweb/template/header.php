<?php  
/*
<!-- header, menu, login,... -->
Coder: Thai Thanh Nhan
Info
    - Email: thanhnhan2tn@mail.com
    - SĐT: 0939 87 00 77
*/
?>
<div id="header">
	<div class="top-head">
    	<div class="left-top-head">
        <span class="logo"></span>
      </div>
        
  </div> <!-- END TOP HEAD -->
    
  <div class="top-menu">
    <nav class="navbar navbar-default" role="navigation">
      <div class="container-fluid">
          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="./"><span class="glyphicon glyphicon-home"></span></a>
          </div>
          <!-- Collect the nav links, forms, and other content for toggling -->
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <div class="right-top-head">
         
              <div class="login-form">
              
              <a href="#login" class="login">Đăng nhập</a>|<a href="#register-box" class="register">Đăng kí</a>
              <!-- popup form #2 -->
              

              <!-- popup form #2 -->
              
            </div>

            <div class="overlay" id="login"></div>
            <div class="popup">
			     <form action="../../../../code/Nhu_login.php" method='post'>
                <label>Tên tài khoản:</label>
                    <input type="text" class="inputname" placeholder="Tài khoản" required>
                <label>Mật khẩu:</label>
                    <input type="password" class="inputpass" placeholder="Mật khẩu" required>
                <div id="remember" class="remember">
                    <label for="cb_cookieuser_navbar"><input type="checkbox" name="cookieuser" value="1" id="cb_cookieuser_navbar" class="cb_cookieuser_navbar" checked="" accesskey="c" tabindex="103"> Ghi nhớ?</label>
                </div>
                    <div class="actionbutton">
                      <input type='submit' name='submit' value='Đăng Nhập' />
    			             <input type="reset" name="reset" value="Huỷ"/>
                      <a href="login.php?do=lostpw" rel="nofollow" class="forgotbutton">Quên mật khẩu</a>
                </div>
            </form>
            <a class="close-box" href="#"></a>
            </div>
            

        </div> <!-- END RIGHT TOP HEAD -->
            <!-- ul class="nav navbar-nav">
              <li class="active"><a href="#">Link</a></li>
              <li><a href="#">Link</a></li>
              <li class="dropdown"></li>
            </ul>
            <ul class="nav navbar-nav right login-box">  
              <li><a href="#login" class="login">Đăng nhập</a></li>
              <li><a href="#register-box" class="register">Đăng kí</a></li>
            </ul -->
         <div class="navi" class="hide">
                      
  <?php 
        require_once('./include/mysqlConnect.php');
        $sql = sprintf('SELECT phuong_name FROM phuong;');
        $rs=$mysqli->query($sql);
        $op_phuong="";
        while($row=$rs->fetch_array()){
          $op_phuong.="<option>{$row[0]}</option>";
        }
        $sql2 = sprintf('SELECT duong_name FROM duong;');
        $rs2=$mysqli->query($sql2);
        $op_duong="";
        while($row=$rs2->fetch_array()){
          $op_duong.="<option>{$row[0]}</option>";
        } 
    
    include ('./include/search.php');
  ?>
          </div>
              <!-- 
                <input type="text" class="left" placeholder="Tài khoản" required>
                <input type="password" class="left" placeholder="Mật khẩu" required>
                <button type="submit" name="submit" style="padding: 1px 5px;">OK</button>
                / -->
              
            

          </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
      </nav>
    <div class="search-area">
    <?php
            include ('./include/search.php');
    ?>
    </div>
  </div> <!--End Top menu -->
   
</div> <!-- END headẻr -->