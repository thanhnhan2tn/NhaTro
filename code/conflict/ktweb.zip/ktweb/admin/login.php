<?php
session_start();
include("function.php");
include("mysqlConnect.php");
//$matkhau = stripslashes($matkhau);
//if (isset($_POST["submit"])){
	$name = m_htmlchars(trim($_REQUEST['username']));
	//$name = str_replace( '|', '&#124;', $name);
	echo $login='select users_name, users_pass from users where users_name like "'.$name.'"';
	$result = mysql_query($login) or die(mysql_error());
	while($arr = mysql_fetch_array($result)){
	echo '<br/>'.$arr['1'];
	}
	$password = stripslashes($_REQUEST['password']);

//}
?>